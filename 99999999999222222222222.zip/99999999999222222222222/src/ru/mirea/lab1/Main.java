package ru.mirea.lab1;

public class Main {

    public static void main(String[] args) {
	for (String str: args){
        System.out.println("Argument=" + str);
    }
    }
}
