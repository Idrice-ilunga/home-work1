package ru.mirea.lab1;
import java.util.Scanner;
public class Main {

    public static int fact(int a){
        int b = 1;
        for (int i = a; i> 0;i--){
            b*= i;
        }
        return b;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Entrer un nombre entier: ");
        int i = sc.nextInt();
        int gnom = fact(i);
        System.out.println("La factorielle de " + i + ": " + gnom);
    }
}
