package ru.mirea.lab1;
import java.util.ArrayList;
import java.util.*;

public class Main {

    public static void main(String[] args) {
        List<Integer> tab = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);
        int i = 0;
        String reponse = new String("y");
        boolean canContinue = true;
        while (canContinue) {
            System.out.print("Saisssez un nombre : ");
            i = scanner.nextInt();
            System.out.println("Nombre : " + i);
            System.out.print("Conitnuer ? (y / n) : ");
            reponse = scanner.next();
            canContinue = reponse.charAt(0) == 'y';
            tab.add(i);
        }

        int min = tab.get(0);
        int max = tab.get(0);
        for (int j = 0; j < tab.size(); j++) {
            if (min > tab.get(j))
                min = tab.get(j);
            if (max < tab.get(j))
                max = tab.get(j);
        }
        System.out.println("Minimum : " + min);
        System.out.println("Maximum : " + max);
    }
}
